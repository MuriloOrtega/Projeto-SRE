import json

def handler(event, context):
    # Simples exemplo de resposta para uma consulta
    return {
        'statusCode': 200,
        'body': json.dumps('Consulta bem-sucedida')
    }
