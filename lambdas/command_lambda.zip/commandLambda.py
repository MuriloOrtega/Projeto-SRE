import json

def handler(event, context):
    # Simples exemplo de resposta para um comando
    return {
        'statusCode': 200,
        'body': json.dumps('Comando bem-sucedido')
    }
